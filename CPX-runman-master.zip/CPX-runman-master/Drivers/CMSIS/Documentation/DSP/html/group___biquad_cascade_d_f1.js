var group___biquad_cascade_d_f1 =
[
    [ "arm_biquad_cascade_df1_f32", "group___biquad_cascade_d_f1.html#gaa0dbe330d763e3c1d8030b3ef12d5bdc", null ],
    [ "arm_biquad_cascade_df1_fast_q15", "group___biquad_cascade_d_f1.html#gaffb9792c0220882efd4c58f3c6a05fd7", null ],
    [ "arm_biquad_cascade_df1_fast_q31", "group___biquad_cascade_d_f1.html#ga456390f5e448afad3a38bed7d6e380e3", null ],
    [ "arm_biquad_cascade_df1_init_f32", "group___biquad_cascade_d_f1.html#ga8e73b69a788e681a61bccc8959d823c5", null ],
    [ "arm_biquad_cascade_df1_init_q15", "group___biquad_cascade_d_f1.html#gad54c724132f6d742a444eb6df0e9c731", null ],
    [ "arm_biquad_cascade_df1_init_q31", "group___biquad_cascade_d_f1.html#gaf42a44f9b16d61e636418c83eefe577b", null ],
    [ "arm_biquad_cascade_df1_q15", "group___biquad_cascade_d_f1.html#gadd66a0aefdc645031d607b0a5b37a942", null ],
    [ "arm_biquad_cascade_df1_q31", "group___biquad_cascade_d_f1.html#ga27b0c54da702713976e5202d20b4473f", null ]
];