var group___linear_interpolate =
[
    [ "arm_linear_interp_f32", "group___linear_interpolate.html#ga2269263d810cafcd19681957b37d5cf6", null ],
    [ "arm_linear_interp_q15", "group___linear_interpolate.html#ga42c9206e5d2d22b8808716dc30622846", null ],
    [ "arm_linear_interp_q31", "group___linear_interpolate.html#ga690e63e9a513ca0a741b1b174805d031", null ],
    [ "arm_linear_interp_q7", "group___linear_interpolate.html#gacb0d44fe00aca0ba1d036d469a1763fc", null ]
];