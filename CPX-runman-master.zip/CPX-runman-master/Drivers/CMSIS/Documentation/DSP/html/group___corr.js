var group___corr =
[
    [ "arm_correlate_f32", "group___corr.html#ga22021e4222773f01e9960358a531cfb8", null ],
    [ "arm_correlate_fast_opt_q15", "group___corr.html#ga40a0236b17220e8e22a22b5bc1c53c6b", null ],
    [ "arm_correlate_fast_q15", "group___corr.html#gac8de3da44f58e86c2c86156276ca154f", null ],
    [ "arm_correlate_fast_q31", "group___corr.html#gabecd3d7b077dbbef43f93e9e037815ed", null ],
    [ "arm_correlate_opt_q15", "group___corr.html#gad71c0ec70ec69edbc48563d9a5f68451", null ],
    [ "arm_correlate_opt_q7", "group___corr.html#ga746e8857cafe33ec5d6780729c18c311", null ],
    [ "arm_correlate_q15", "group___corr.html#ga5ec96b8e420d68b0e626df0812274d46", null ],
    [ "arm_correlate_q31", "group___corr.html#ga1367dc6c80476406c951e68d7fac4e8c", null ],
    [ "arm_correlate_q7", "group___corr.html#ga284ddcc49e4ac532d52a70d0383c5992", null ]
];