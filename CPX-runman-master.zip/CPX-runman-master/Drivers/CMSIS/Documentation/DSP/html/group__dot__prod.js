var group__dot__prod =
[
    [ "arm_dot_prod_f32", "group__dot__prod.html#ga55418d4362f6ba84c327f9b4f089a8c3", null ],
    [ "arm_dot_prod_q15", "group__dot__prod.html#ga436d5bed28a4b73b24acbde436a3044b", null ],
    [ "arm_dot_prod_q31", "group__dot__prod.html#gab15d8fa060fc85b4d948d091b7deaa11", null ],
    [ "arm_dot_prod_q7", "group__dot__prod.html#ga9c3293a50ac7ec8ba928bf8e3aaea6c1", null ]
];