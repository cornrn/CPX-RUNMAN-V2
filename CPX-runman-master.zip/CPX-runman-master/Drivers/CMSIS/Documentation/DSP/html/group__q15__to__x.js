var group__q15__to__x =
[
    [ "arm_q15_to_float", "group__q15__to__x.html#gaf8b0d2324de273fc430b0e61ad4e9eb2", null ],
    [ "arm_q15_to_q31", "group__q15__to__x.html#ga7ba2d87366990ad5380439e2b4a4c0a5", null ],
    [ "arm_q15_to_q7", "group__q15__to__x.html#ga8fb31855ff8cce09c2ec9308f48ded69", null ]
];