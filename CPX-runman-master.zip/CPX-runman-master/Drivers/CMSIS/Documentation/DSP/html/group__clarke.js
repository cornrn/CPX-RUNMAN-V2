var group__clarke =
[
    [ "arm_clarke_f32", "group__clarke.html#ga2b4ebec76215e1277c970c269ffdbd76", null ],
    [ "arm_clarke_q31", "group__clarke.html#ga7fd106ca8d346a2a472842e0656014c1", null ]
];