var structarm__fir__instance__q15 =
[
    [ "numTaps", "structarm__fir__instance__q15.html#a0e46f93cf51bfb18b1be808be9c5bfc9", null ],
    [ "pCoeffs", "structarm__fir__instance__q15.html#a6d16db16a5f8f0db54938f2967244d9e", null ],
    [ "pState", "structarm__fir__instance__q15.html#aa8d25f44f45b6a6c4cf38c31569b8a01", null ]
];