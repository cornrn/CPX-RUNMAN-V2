var group___f_i_r__decimate =
[
    [ "arm_fir_decimate_f32", "group___f_i_r__decimate.html#ga25aa3d58a90bf91b6a82272a0bc518f7", null ],
    [ "arm_fir_decimate_fast_q15", "group___f_i_r__decimate.html#ga3f434c9a5d3b4e68061feac0714ea2ac", null ],
    [ "arm_fir_decimate_fast_q31", "group___f_i_r__decimate.html#ga3c18cc3d0548a410c577f1bead9582b7", null ],
    [ "arm_fir_decimate_init_f32", "group___f_i_r__decimate.html#gaaa2524b08220fd6c3f753e692ffc7d3b", null ],
    [ "arm_fir_decimate_init_q15", "group___f_i_r__decimate.html#gada660e54b93d5d32178c6f5e1c6f368d", null ],
    [ "arm_fir_decimate_init_q31", "group___f_i_r__decimate.html#ga9ed47c4e0f58affa935d84e0508a7f39", null ],
    [ "arm_fir_decimate_q15", "group___f_i_r__decimate.html#gab8bef6d0f6a26fdbfce9485727713ce5", null ],
    [ "arm_fir_decimate_q31", "group___f_i_r__decimate.html#gaef8e86add28f15fdc5ecc484e9dd7a4e", null ]
];