var group__group_matrix =
[
    [ "Matrix Addition", "group___matrix_add.html", "group___matrix_add" ],
    [ "Complex Matrix Multiplication", "group___cmplx_matrix_mult.html", "group___cmplx_matrix_mult" ],
    [ "Matrix Initialization", "group___matrix_init.html", "group___matrix_init" ],
    [ "Matrix Inverse", "group___matrix_inv.html", "group___matrix_inv" ],
    [ "Matrix Multiplication", "group___matrix_mult.html", "group___matrix_mult" ],
    [ "Matrix Scale", "group___matrix_scale.html", "group___matrix_scale" ],
    [ "Matrix Subtraction", "group___matrix_sub.html", "group___matrix_sub" ],
    [ "Matrix Transpose", "group___matrix_trans.html", "group___matrix_trans" ]
];