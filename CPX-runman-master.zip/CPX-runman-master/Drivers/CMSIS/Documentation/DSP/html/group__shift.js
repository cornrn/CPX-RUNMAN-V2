var group__shift =
[
    [ "arm_shift_q15", "group__shift.html#gaa1757e53279780107acc92cf100adb61", null ],
    [ "arm_shift_q31", "group__shift.html#ga387dd8b7b87377378280978f16cdb13d", null ],
    [ "arm_shift_q7", "group__shift.html#ga47295d08a685f7de700a48dafb4db6fb", null ]
];