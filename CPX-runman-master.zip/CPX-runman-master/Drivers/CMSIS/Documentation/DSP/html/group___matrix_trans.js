var group___matrix_trans =
[
    [ "arm_mat_trans_f32", "group___matrix_trans.html#gad7dd9f108429da13d3864696ceeec789", null ],
    [ "arm_mat_trans_q15", "group___matrix_trans.html#ga4f4f821cc695fd0ef9061d702e08050a", null ],
    [ "arm_mat_trans_q31", "group___matrix_trans.html#ga30a4d49489ac67ff98a46b9f58f73bf1", null ]
];