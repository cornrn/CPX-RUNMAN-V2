var structarm__biquad__cascade__stereo__df2_t__instance__f32 =
[
    [ "numStages", "structarm__biquad__cascade__stereo__df2_t__instance__f32.html#a5655328252da5c2c2425ceed253bc4f1", null ],
    [ "pCoeffs", "structarm__biquad__cascade__stereo__df2_t__instance__f32.html#a58b15644de62a632c5e9d4a563569dc6", null ],
    [ "pState", "structarm__biquad__cascade__stereo__df2_t__instance__f32.html#a2cb00048bb1fe957a03c1ff56dfaf8f0", null ]
];