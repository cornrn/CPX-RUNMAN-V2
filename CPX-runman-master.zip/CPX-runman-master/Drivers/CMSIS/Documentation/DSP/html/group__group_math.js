var group__group_math =
[
    [ "Vector Absolute Value", "group___basic_abs.html", "group___basic_abs" ],
    [ "Vector Addition", "group___basic_add.html", "group___basic_add" ],
    [ "Vector Dot Product", "group__dot__prod.html", "group__dot__prod" ],
    [ "Vector Multiplication", "group___basic_mult.html", "group___basic_mult" ],
    [ "Vector Negate", "group__negate.html", "group__negate" ],
    [ "Vector Offset", "group__offset.html", "group__offset" ],
    [ "Vector Scale", "group__scale.html", "group__scale" ],
    [ "Vector Shift", "group__shift.html", "group__shift" ],
    [ "Vector Subtraction", "group___basic_sub.html", "group___basic_sub" ]
];