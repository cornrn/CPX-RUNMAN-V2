var group__q7__to__x =
[
    [ "arm_q7_to_float", "group__q7__to__x.html#ga656620f957b65512ed83db03fd455ec5", null ],
    [ "arm_q7_to_q15", "group__q7__to__x.html#gabc02597fc3f01033daf43ec0547a2f78", null ],
    [ "arm_q7_to_q31", "group__q7__to__x.html#gad8958cd3cb7f521466168b46a25b7908", null ]
];