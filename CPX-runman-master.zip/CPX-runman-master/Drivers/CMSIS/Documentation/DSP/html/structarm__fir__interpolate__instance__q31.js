var structarm__fir__interpolate__instance__q31 =
[
    [ "L", "structarm__fir__interpolate__instance__q31.html#a5cdf0a631cb74e0e9588c388abe5235c", null ],
    [ "pCoeffs", "structarm__fir__interpolate__instance__q31.html#afa719433687e1936ec3403d0d32f06e6", null ],
    [ "phaseLength", "structarm__fir__interpolate__instance__q31.html#a5d243796584afc7cd6c557f00b7acca5", null ],
    [ "pState", "structarm__fir__interpolate__instance__q31.html#addde04514b6e6ac72be3d609f0398b1a", null ]
];