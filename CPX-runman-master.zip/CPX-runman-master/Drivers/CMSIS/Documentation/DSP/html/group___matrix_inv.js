var group___matrix_inv =
[
    [ "arm_mat_inverse_f32", "group___matrix_inv.html#ga542be7aabbf7a2297a4b62cf212910e3", null ],
    [ "arm_mat_inverse_f64", "group___matrix_inv.html#gaede2367c02df083cc915ddd5d8fae838", null ]
];