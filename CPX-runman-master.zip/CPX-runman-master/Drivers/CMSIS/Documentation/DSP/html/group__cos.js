var group__cos =
[
    [ "arm_cos_f32", "group__cos.html#gace15287f9c64b9b4084d1c797d4c49d8", null ],
    [ "arm_cos_q15", "group__cos.html#gadfd60c24def501638c0d5db20f4c869b", null ],
    [ "arm_cos_q31", "group__cos.html#gad80f121949ef885a77d83ab36e002567", null ]
];