var structarm__cfft__instance__q31 =
[
    [ "bitRevLength", "structarm__cfft__instance__q31.html#a2250fa6b8fe73292c5418c50c0549f87", null ],
    [ "fftLen", "structarm__cfft__instance__q31.html#a4406f23e8fd0bff8d555225612e2a2a8", null ],
    [ "pBitRevTable", "structarm__cfft__instance__q31.html#a8a464461649f023325ced1e10470f5d0", null ],
    [ "pTwiddle", "structarm__cfft__instance__q31.html#af751114feb91de3ace8600e91bdd0872", null ]
];