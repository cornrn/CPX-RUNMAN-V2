var structarm__cfft__instance__q15 =
[
    [ "bitRevLength", "structarm__cfft__instance__q15.html#a738907cf34bdbbaf724414ac2decbc3c", null ],
    [ "fftLen", "structarm__cfft__instance__q15.html#a5f9e1d3a8c127ee323b5e6929aeb90df", null ],
    [ "pBitRevTable", "structarm__cfft__instance__q15.html#ac9160b80243b99a0b6e2f75ddb5cf0ae", null ],
    [ "pTwiddle", "structarm__cfft__instance__q15.html#afdaf12ce4687cec021c5ae73d0987a3f", null ]
];