var structarm__dct4__instance__q15 =
[
    [ "N", "structarm__dct4__instance__q15.html#a53d24009bb9b2e93d0aa07db7f1a6c25", null ],
    [ "Nby2", "structarm__dct4__instance__q15.html#af43dcbbc2fc661ffbc525afe3dcbd7da", null ],
    [ "normalize", "structarm__dct4__instance__q15.html#a197098140d68e89a08f7a249003a0b86", null ],
    [ "pCfft", "structarm__dct4__instance__q15.html#a7284932ee8c36107c33815eb62eadffc", null ],
    [ "pCosFactor", "structarm__dct4__instance__q15.html#ac76df681b1bd502fb4874c06f055dded", null ],
    [ "pRfft", "structarm__dct4__instance__q15.html#a11cf95c1cd9dd2dd5e4b81b8f88dc208", null ],
    [ "pTwiddle", "structarm__dct4__instance__q15.html#abc6c847e9f906781e1d5da40e9aafa76", null ]
];