var group__sin =
[
    [ "arm_sin_f32", "group__sin.html#gae164899c4a3fc0e946dc5d55555fe541", null ],
    [ "arm_sin_q15", "group__sin.html#ga1fc6d6640be6cfa688a8bea0a48397ee", null ],
    [ "arm_sin_q31", "group__sin.html#ga57aade7d8892585992cdc6375bd82f9c", null ]
];