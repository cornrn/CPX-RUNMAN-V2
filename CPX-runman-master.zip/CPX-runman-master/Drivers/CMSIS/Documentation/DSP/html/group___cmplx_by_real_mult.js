var group___cmplx_by_real_mult =
[
    [ "arm_cmplx_mult_real_f32", "group___cmplx_by_real_mult.html#ga9c18616f56cb4d3c0889ce0b339221ca", null ],
    [ "arm_cmplx_mult_real_q15", "group___cmplx_by_real_mult.html#ga3bd8889dcb45980e1d3e53344df54e85", null ],
    [ "arm_cmplx_mult_real_q31", "group___cmplx_by_real_mult.html#ga715e4bb8e945b8ca51ec5237611697ce", null ]
];