var structarm__fir__sparse__instance__q15 =
[
    [ "maxDelay", "structarm__fir__sparse__instance__q15.html#ad14cc1070eecf7e1926d8f67a8273182", null ],
    [ "numTaps", "structarm__fir__sparse__instance__q15.html#a0f66b126dd8b85f7467cfb01b7bc4d77", null ],
    [ "pCoeffs", "structarm__fir__sparse__instance__q15.html#a78a6565473b5f0b8c77c3f0f58a76069", null ],
    [ "pState", "structarm__fir__sparse__instance__q15.html#a98b92b0f5208110129b9a67b1db90408", null ],
    [ "pTapDelay", "structarm__fir__sparse__instance__q15.html#aeab2855176c6efdb231a73a3672837d5", null ],
    [ "stateIndex", "structarm__fir__sparse__instance__q15.html#a89487f28cab52637426024005e478985", null ]
];