var structarm__bilinear__interp__instance__q31 =
[
    [ "numCols", "structarm__bilinear__interp__instance__q31.html#a6c3eff4eb17ff1d43f170efb84713a2d", null ],
    [ "numRows", "structarm__bilinear__interp__instance__q31.html#a2082e3eac56354d75291f03e96ce4aa5", null ],
    [ "pData", "structarm__bilinear__interp__instance__q31.html#a843eae0c9db5f815e77e1aaf9afea358", null ]
];