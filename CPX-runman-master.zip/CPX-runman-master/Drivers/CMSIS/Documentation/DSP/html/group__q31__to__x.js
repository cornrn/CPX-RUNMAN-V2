var group__q31__to__x =
[
    [ "arm_q31_to_float", "group__q31__to__x.html#gacf407b007a37da18e99dabd9023c56b4", null ],
    [ "arm_q31_to_q15", "group__q31__to__x.html#ga901dede4661365c9e7c630d3eb31c32c", null ],
    [ "arm_q31_to_q7", "group__q31__to__x.html#ga7f297d1a7d776805395095fdb24a8071", null ]
];