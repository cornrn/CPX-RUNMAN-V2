var structarm__bilinear__interp__instance__q7 =
[
    [ "numCols", "structarm__bilinear__interp__instance__q7.html#a860dd0d24380ea06cfbb348fb3b12c9a", null ],
    [ "numRows", "structarm__bilinear__interp__instance__q7.html#ad5a8067cab5f9ea4688b11a623e16607", null ],
    [ "pData", "structarm__bilinear__interp__instance__q7.html#af05194d691bbefb02c34bafb22ca9ef0", null ]
];