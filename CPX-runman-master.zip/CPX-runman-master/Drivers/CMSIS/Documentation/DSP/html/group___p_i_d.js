var group___p_i_d =
[
    [ "arm_pid_f32", "group___p_i_d.html#gac5c79ed46abf2d72b8cf41fa6c708bda", null ],
    [ "arm_pid_init_f32", "group___p_i_d.html#gae31536b19b82b93ed184fb1ab73cfcb3", null ],
    [ "arm_pid_init_q15", "group___p_i_d.html#ga2cb1e3d3ebb167348fdabec74653d5c3", null ],
    [ "arm_pid_init_q31", "group___p_i_d.html#gad9d88485234fa9460b1ce9e64989ac86", null ],
    [ "arm_pid_q15", "group___p_i_d.html#ga084f646bbb20d55f225c3efafcf7fc1f", null ],
    [ "arm_pid_q31", "group___p_i_d.html#ga5f6f941e7ae981728dd3a662f8f4ecd7", null ],
    [ "arm_pid_reset_f32", "group___p_i_d.html#ga9ec860bcb6f8ca31205bf0f1b51ab723", null ],
    [ "arm_pid_reset_q15", "group___p_i_d.html#ga408566dacb4fa6e0458b2c75672e525f", null ],
    [ "arm_pid_reset_q31", "group___p_i_d.html#gaeecbacd3fb37c608ec25474d3a0dffa9", null ]
];