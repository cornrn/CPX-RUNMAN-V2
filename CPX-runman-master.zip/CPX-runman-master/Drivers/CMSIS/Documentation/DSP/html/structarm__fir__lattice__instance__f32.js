var structarm__fir__lattice__instance__f32 =
[
    [ "numStages", "structarm__fir__lattice__instance__f32.html#ad369bd9997a250f195254df37408a38f", null ],
    [ "pCoeffs", "structarm__fir__lattice__instance__f32.html#a33bf5948c947f9ef80a99717cb0a0a43", null ],
    [ "pState", "structarm__fir__lattice__instance__f32.html#ae348884a1ba9b83fadccd5da640cbcaf", null ]
];