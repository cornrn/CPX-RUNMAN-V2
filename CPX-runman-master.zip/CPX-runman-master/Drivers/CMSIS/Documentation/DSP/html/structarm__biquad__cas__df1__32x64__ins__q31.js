var structarm__biquad__cas__df1__32x64__ins__q31 =
[
    [ "numStages", "structarm__biquad__cas__df1__32x64__ins__q31.html#ad7cb9a9f5df8f4fcfc7a0b633672e574", null ],
    [ "pCoeffs", "structarm__biquad__cas__df1__32x64__ins__q31.html#a490462d6ebe0fecfb6acbf51bed22ecf", null ],
    [ "postShift", "structarm__biquad__cas__df1__32x64__ins__q31.html#a8e9d58e8dba5aa3b2fc4f36d2ed07996", null ],
    [ "pState", "structarm__biquad__cas__df1__32x64__ins__q31.html#a4c899cdfaf2bb955323e93637bd662e0", null ]
];