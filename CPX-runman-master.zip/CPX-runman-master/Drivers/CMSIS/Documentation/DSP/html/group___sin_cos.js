var group___sin_cos =
[
    [ "arm_sin_cos_f32", "group___sin_cos.html#ga4420d45c37d58c310ef9ae1b5fe58020", null ],
    [ "arm_sin_cos_q31", "group___sin_cos.html#gae9e4ddebff9d4eb5d0a093e28e0bc504", null ]
];