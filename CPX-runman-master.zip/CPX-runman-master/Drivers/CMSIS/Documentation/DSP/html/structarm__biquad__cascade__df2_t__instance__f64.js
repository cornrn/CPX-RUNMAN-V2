var structarm__biquad__cascade__df2_t__instance__f64 =
[
    [ "numStages", "structarm__biquad__cascade__df2_t__instance__f64.html#ad55380ff835b533aa5168f836db8a4de", null ],
    [ "pCoeffs", "structarm__biquad__cascade__df2_t__instance__f64.html#ae2f0180f9038c0393e1d6921bb3b878b", null ],
    [ "pState", "structarm__biquad__cascade__df2_t__instance__f64.html#a0bde57b618e3f9059b23b0de64e12ce3", null ]
];