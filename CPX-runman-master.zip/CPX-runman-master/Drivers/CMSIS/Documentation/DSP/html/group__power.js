var group__power =
[
    [ "arm_power_f32", "group__power.html#ga993c00dd7f661d66bdb6e58426e893aa", null ],
    [ "arm_power_q15", "group__power.html#ga7050c04b7515e01a75c38f1abbaf71ba", null ],
    [ "arm_power_q31", "group__power.html#ga0b93d31bb5b5ed214c2b94d8a7744cd2", null ],
    [ "arm_power_q7", "group__power.html#gaf969c85c5655e3d72d7b99ff188f92c9", null ]
];