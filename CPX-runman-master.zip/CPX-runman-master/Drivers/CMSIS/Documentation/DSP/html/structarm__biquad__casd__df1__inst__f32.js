var structarm__biquad__casd__df1__inst__f32 =
[
    [ "numStages", "structarm__biquad__casd__df1__inst__f32.html#af69820c37a87252c46453e4cfe120585", null ],
    [ "pCoeffs", "structarm__biquad__casd__df1__inst__f32.html#af9df3820576fb921809d1462c9c6d16c", null ],
    [ "pState", "structarm__biquad__casd__df1__inst__f32.html#a8c245d79e0d8cfabc82409d4b54fb682", null ]
];