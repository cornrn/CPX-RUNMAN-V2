var group___real_f_f_t =
[
    [ "arm_rfft_f32", "group___real_f_f_t.html#ga3df1766d230532bc068fc4ed69d0fcdc", null ],
    [ "arm_rfft_fast_f32", "group___real_f_f_t.html#ga180d8b764d59cbb85d37a2d5f7cd9799", null ],
    [ "arm_rfft_fast_init_f32", "group___real_f_f_t.html#gac5fceb172551e7c11eb4d0e17ef15aa3", null ],
    [ "arm_rfft_init_f32", "group___real_f_f_t.html#ga10717ee326bf50832ef1c25b85a23068", null ],
    [ "arm_rfft_init_q15", "group___real_f_f_t.html#ga053450cc600a55410ba5b5605e96245d", null ],
    [ "arm_rfft_init_q31", "group___real_f_f_t.html#ga5abde938abbe72e95c5bab080eb33c45", null ],
    [ "arm_rfft_q15", "group___real_f_f_t.html#ga00e615f5db21736ad5b27fb6146f3fc5", null ],
    [ "arm_rfft_q31", "group___real_f_f_t.html#gabaeab5646aeea9844e6d42ca8c73fe3a", null ],
    [ "realCoefA", "group___real_f_f_t.html#ga8b1ad947c470596674fa3364e16045c6", null ],
    [ "realCoefAQ15", "group___real_f_f_t.html#ga11e84d0ee257a547f749b37dd0078d36", null ],
    [ "realCoefAQ31", "group___real_f_f_t.html#gaf1592a6cf0504675205074a43c3728a2", null ],
    [ "realCoefB", "group___real_f_f_t.html#gac52f98b52a1f03bfac8b57a67ba07397", null ],
    [ "realCoefBQ15", "group___real_f_f_t.html#gac871666f018b70938b2b98017628cb97", null ],
    [ "realCoefBQ31", "group___real_f_f_t.html#ga1eb5745728a61c3715755f5d69a4a960", null ]
];