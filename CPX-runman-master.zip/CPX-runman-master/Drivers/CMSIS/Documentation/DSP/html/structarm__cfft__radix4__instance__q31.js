var structarm__cfft__radix4__instance__q31 =
[
    [ "bitReverseFlag", "structarm__cfft__radix4__instance__q31.html#a5a7c4f4c7b3fb655cbb2bc11ef160a2a", null ],
    [ "bitRevFactor", "structarm__cfft__radix4__instance__q31.html#a94d2fead4efa4d5eaae142bbe30b0e15", null ],
    [ "fftLen", "structarm__cfft__radix4__instance__q31.html#ab413d2a5d3f45fa187d93813bf3bf81b", null ],
    [ "ifftFlag", "structarm__cfft__radix4__instance__q31.html#adc0a62ba669ad2282ecbe43d5d96abab", null ],
    [ "pBitRevTable", "structarm__cfft__radix4__instance__q31.html#a33a3bc774c97373261699463c05dfe54", null ],
    [ "pTwiddle", "structarm__cfft__radix4__instance__q31.html#a561c22dee4cbdcfa0fd5f15106ecc306", null ],
    [ "twidCoefModifier", "structarm__cfft__radix4__instance__q31.html#a8cf8187b8232815cf17ee82bf572ecf9", null ]
];