var group__offset =
[
    [ "arm_offset_f32", "group__offset.html#ga989dfae15235799d82f62ef9d356abb4", null ],
    [ "arm_offset_q15", "group__offset.html#gab4c1d2391b599549e5a06fdfbc2747bf", null ],
    [ "arm_offset_q31", "group__offset.html#gac84ec42cbbebc5c197a87d0221819acf", null ],
    [ "arm_offset_q7", "group__offset.html#ga00bd9cc17c5bf905e76c91ad50886393", null ]
];