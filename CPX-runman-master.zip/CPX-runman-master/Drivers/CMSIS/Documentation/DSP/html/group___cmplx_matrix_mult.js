var group___cmplx_matrix_mult =
[
    [ "arm_mat_cmplx_mult_f32", "group___cmplx_matrix_mult.html#ga1adb839ac84445b8c2f04efa43faef35", null ],
    [ "arm_mat_cmplx_mult_q15", "group___cmplx_matrix_mult.html#ga63066615e7d6f6a44f4358725092419e", null ],
    [ "arm_mat_cmplx_mult_q31", "group___cmplx_matrix_mult.html#gaaf3c0b171ca8412c77bab9fa90804737", null ]
];