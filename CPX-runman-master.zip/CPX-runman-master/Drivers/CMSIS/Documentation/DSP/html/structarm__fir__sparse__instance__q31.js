var structarm__fir__sparse__instance__q31 =
[
    [ "maxDelay", "structarm__fir__sparse__instance__q31.html#afdd3a1dc72132c854dc379154b68b674", null ],
    [ "numTaps", "structarm__fir__sparse__instance__q31.html#a07b6c01e58ec6dde384719130d36b0dc", null ],
    [ "pCoeffs", "structarm__fir__sparse__instance__q31.html#a093d6227f0d1597982cd083fb126f4e0", null ],
    [ "pState", "structarm__fir__sparse__instance__q31.html#a830be89daa5a393b225048889aa045d1", null ],
    [ "pTapDelay", "structarm__fir__sparse__instance__q31.html#ab87ae457adec8f727afefaa2599fc983", null ],
    [ "stateIndex", "structarm__fir__sparse__instance__q31.html#a557ed9d477e76e4ad2019344f19f568a", null ]
];