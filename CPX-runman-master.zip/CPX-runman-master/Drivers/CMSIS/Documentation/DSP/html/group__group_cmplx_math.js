var group__group_cmplx_math =
[
    [ "Complex Conjugate", "group__cmplx__conj.html", "group__cmplx__conj" ],
    [ "Complex Dot Product", "group__cmplx__dot__prod.html", "group__cmplx__dot__prod" ],
    [ "Complex Magnitude", "group__cmplx__mag.html", "group__cmplx__mag" ],
    [ "Complex Magnitude Squared", "group__cmplx__mag__squared.html", "group__cmplx__mag__squared" ],
    [ "Complex-by-Complex Multiplication", "group___cmplx_by_cmplx_mult.html", "group___cmplx_by_cmplx_mult" ],
    [ "Complex-by-Real Multiplication", "group___cmplx_by_real_mult.html", "group___cmplx_by_real_mult" ]
];