var searchData=
[
  ['controller_5fq31_5fshift',['CONTROLLER_Q31_SHIFT',['../arm__math_8h.html#aaff6d2358c4ada8de838a279254ab550',1,'arm_math.h']]]
];
