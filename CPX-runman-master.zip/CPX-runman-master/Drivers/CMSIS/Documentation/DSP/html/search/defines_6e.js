var searchData=
[
  ['num_5ftaps',['NUM_TAPS',['../arm__fir__example__f32_8c.html#a7579d94e0a80fb9d376ea6c7897f73b0',1,'arm_fir_example_f32.c']]],
  ['numblocks',['NUMBLOCKS',['../arm__graphic__equalizer__example__q31_8c.html#a814e34126e1b8150f4de047e1a9e7030',1,'arm_graphic_equalizer_example_q31.c']]],
  ['numframes',['NUMFRAMES',['../arm__signal__converge__example__f32_8c.html#a4b6b859e1e3f6021a360390be287ca2c',1,'arm_signal_converge_example_f32.c']]],
  ['numstages',['NUMSTAGES',['../arm__graphic__equalizer__example__q31_8c.html#a23f8e430b510dfdb3ebe53bffca0d864',1,'arm_graphic_equalizer_example_q31.c']]],
  ['numstudents',['NUMSTUDENTS',['../_a_r_m_2arm__class__marks__example__f32_8c.html#a9d89ac0707e7c9363544986d47a70bd3',1,'NUMSTUDENTS():&#160;arm_class_marks_example_f32.c'],['../_g_c_c_2arm__class__marks__example__f32_8c.html#a9d89ac0707e7c9363544986d47a70bd3',1,'NUMSTUDENTS():&#160;arm_class_marks_example_f32.c']]],
  ['numsubjects',['NUMSUBJECTS',['../_a_r_m_2arm__class__marks__example__f32_8c.html#a7b02f9b34bf2cd4d12633f5bf30771ec',1,'NUMSUBJECTS():&#160;arm_class_marks_example_f32.c'],['../_g_c_c_2arm__class__marks__example__f32_8c.html#a7b02f9b34bf2cd4d12633f5bf30771ec',1,'NUMSUBJECTS():&#160;arm_class_marks_example_f32.c']]],
  ['numtaps',['NUMTAPS',['../arm__signal__converge__example__f32_8c.html#ac1d8ddb4f9a957eef3ad13d44de4d804',1,'arm_signal_converge_example_f32.c']]]
];
