var searchData=
[
  ['statistics_20functions',['Statistics Functions',['../group__group_stats.html',1,'']]],
  ['support_20functions',['Support Functions',['../group__group_support.html',1,'']]],
  ['signal_20convergence_20example',['Signal Convergence Example',['../group___signal_convergence.html',1,'']]],
  ['sine',['Sine',['../group__sin.html',1,'']]],
  ['sine_20cosine',['Sine Cosine',['../group___sin_cos.html',1,'']]],
  ['sinecosine_20example',['SineCosine Example',['../group___sin_cos_example.html',1,'']]],
  ['square_20root',['Square Root',['../group___s_q_r_t.html',1,'']]],
  ['standard_20deviation',['Standard deviation',['../group___s_t_d.html',1,'']]]
];
