var searchData=
[
  ['real_20fft_20functions',['Real FFT Functions',['../group___fast.html',1,'']]],
  ['radix_2d8_20complex_20fft_20functions',['Radix-8 Complex FFT Functions',['../group___radix8___c_f_f_t___c_i_f_f_t.html',1,'']]],
  ['realfft',['RealFFT',['../group___real_f_f_t.html',1,'']]],
  ['root_20mean_20square_20_28rms_29',['Root mean square (RMS)',['../group___r_m_s.html',1,'']]]
];
