var searchData=
[
  ['float32_5ft',['float32_t',['../arm__math_8h.html#a4611b605e45ab401f02cab15c5e38715',1,'arm_math.h']]],
  ['float64_5ft',['float64_t',['../arm__math_8h.html#ac55f3ae81b5bc9053760baacf57e47f4',1,'arm_math.h']]]
];
