var searchData=
[
  ['delta',['DELTA',['../_a_r_m_2arm__convolution__example__f32_8c.html#a3fd2b1bcd7ddcf506237987ad780f495',1,'DELTA():&#160;arm_convolution_example_f32.c'],['../_g_c_c_2arm__convolution__example__f32_8c.html#a3fd2b1bcd7ddcf506237987ad780f495',1,'DELTA():&#160;arm_convolution_example_f32.c'],['../_a_r_m_2arm__dotproduct__example__f32_8c.html#a3fd2b1bcd7ddcf506237987ad780f495',1,'DELTA():&#160;arm_dotproduct_example_f32.c'],['../_g_c_c_2arm__dotproduct__example__f32_8c.html#a3fd2b1bcd7ddcf506237987ad780f495',1,'DELTA():&#160;arm_dotproduct_example_f32.c'],['../arm__sin__cos__example__f32_8c.html#a3fd2b1bcd7ddcf506237987ad780f495',1,'DELTA():&#160;arm_sin_cos_example_f32.c'],['../arm__variance__example__f32_8c.html#a3fd2b1bcd7ddcf506237987ad780f495',1,'DELTA():&#160;arm_variance_example_f32.c']]],
  ['delta_5fcoeff',['DELTA_COEFF',['../arm__signal__converge__example__f32_8c.html#a9156349d99957ded15d8aa3aa11723de',1,'arm_signal_converge_example_f32.c']]],
  ['delta_5ferror',['DELTA_ERROR',['../arm__signal__converge__example__f32_8c.html#a6d3c6a4484dcaac72fbfe5100c39b9b6',1,'arm_signal_converge_example_f32.c']]],
  ['delta_5fq15',['DELTA_Q15',['../arm__math_8h.html#a663277ff19ad0b409fb98b64b2c2750b',1,'arm_math.h']]],
  ['delta_5fq31',['DELTA_Q31',['../arm__math_8h.html#aad77ae594e95c5af6ae4129bd6a483c2',1,'arm_math.h']]]
];
