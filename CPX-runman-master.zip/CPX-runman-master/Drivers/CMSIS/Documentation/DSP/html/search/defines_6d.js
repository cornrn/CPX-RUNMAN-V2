var searchData=
[
  ['max_5fblocksize',['MAX_BLOCKSIZE',['../_a_r_m_2arm__convolution__example__f32_8c.html#af8a1d2ed31f7c9a00fec46a798edb61b',1,'MAX_BLOCKSIZE():&#160;arm_convolution_example_f32.c'],['../_g_c_c_2arm__convolution__example__f32_8c.html#af8a1d2ed31f7c9a00fec46a798edb61b',1,'MAX_BLOCKSIZE():&#160;arm_convolution_example_f32.c'],['../_a_r_m_2arm__dotproduct__example__f32_8c.html#af8a1d2ed31f7c9a00fec46a798edb61b',1,'MAX_BLOCKSIZE():&#160;arm_dotproduct_example_f32.c'],['../_g_c_c_2arm__dotproduct__example__f32_8c.html#af8a1d2ed31f7c9a00fec46a798edb61b',1,'MAX_BLOCKSIZE():&#160;arm_dotproduct_example_f32.c'],['../arm__sin__cos__example__f32_8c.html#af8a1d2ed31f7c9a00fec46a798edb61b',1,'MAX_BLOCKSIZE():&#160;arm_sin_cos_example_f32.c'],['../arm__variance__example__f32_8c.html#af8a1d2ed31f7c9a00fec46a798edb61b',1,'MAX_BLOCKSIZE():&#160;arm_variance_example_f32.c']]],
  ['mu',['MU',['../arm__signal__converge__example__f32_8c.html#a09bc9e6a44f0291cfcf578f2efcddfab',1,'arm_signal_converge_example_f32.c']]],
  ['mult_5f32x32_5fkeep32',['mult_32x32_keep32',['../arm__math_8h.html#abb4baa0192bbb6fabc9251af4b4cb322',1,'arm_math.h']]],
  ['mult_5f32x32_5fkeep32_5fr',['mult_32x32_keep32_R',['../arm__math_8h.html#a960f210642058d2b3d5368729a6e8375',1,'arm_math.h']]],
  ['multacc_5f32x32_5fkeep32',['multAcc_32x32_keep32',['../arm__math_8h.html#a58454519e12e8157f0a1c36071333655',1,'arm_math.h']]],
  ['multacc_5f32x32_5fkeep32_5fr',['multAcc_32x32_keep32_R',['../arm__math_8h.html#aba3e538352fc7f9d6d15f9a18d469399',1,'arm_math.h']]],
  ['multsub_5f32x32_5fkeep32',['multSub_32x32_keep32',['../arm__math_8h.html#a9ec66f3082a4c65c78075638255f42ab',1,'arm_math.h']]],
  ['multsub_5f32x32_5fkeep32_5fr',['multSub_32x32_keep32_R',['../arm__math_8h.html#a668fbf1cd1c3bc8faf1b1c83964ade23',1,'arm_math.h']]]
];
