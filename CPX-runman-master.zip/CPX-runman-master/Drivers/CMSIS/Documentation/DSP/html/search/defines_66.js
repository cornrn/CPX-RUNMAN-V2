var searchData=
[
  ['fast_5fmath_5fq15_5fshift',['FAST_MATH_Q15_SHIFT',['../arm__math_8h.html#a34716b73c631e65e8dd855e08384ecb2',1,'arm_math.h']]],
  ['fast_5fmath_5fq31_5fshift',['FAST_MATH_Q31_SHIFT',['../arm__math_8h.html#a4268f77b1811a0c7fc2532a0bf6108b0',1,'arm_math.h']]],
  ['fast_5fmath_5ftable_5fsize',['FAST_MATH_TABLE_SIZE',['../arm__math_8h.html#afcb9147c96853bea484cfc2dde07463d',1,'arm_math.h']]]
];
