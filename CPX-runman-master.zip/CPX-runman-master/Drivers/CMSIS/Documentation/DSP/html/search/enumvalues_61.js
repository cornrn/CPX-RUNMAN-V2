var searchData=
[
  ['arm_5fmath_5fargument_5ferror',['ARM_MATH_ARGUMENT_ERROR',['../arm__math_8h.html#a5e459c6409dfcd2927bb8a57491d7cf6a74897e18d4b8f62b12a7d8a01dd2bb35',1,'arm_math.h']]],
  ['arm_5fmath_5flength_5ferror',['ARM_MATH_LENGTH_ERROR',['../arm__math_8h.html#a5e459c6409dfcd2927bb8a57491d7cf6a9ae74d7f8a53aec0512ae8f0a421e0e1',1,'arm_math.h']]],
  ['arm_5fmath_5fnaninf',['ARM_MATH_NANINF',['../arm__math_8h.html#a5e459c6409dfcd2927bb8a57491d7cf6ac55996aaf19245238a8f57a91aeaefcc',1,'arm_math.h']]],
  ['arm_5fmath_5fsingular',['ARM_MATH_SINGULAR',['../arm__math_8h.html#a5e459c6409dfcd2927bb8a57491d7cf6a91509ea9c819dbd592ac13a6b05382dc',1,'arm_math.h']]],
  ['arm_5fmath_5fsize_5fmismatch',['ARM_MATH_SIZE_MISMATCH',['../arm__math_8h.html#a5e459c6409dfcd2927bb8a57491d7cf6a7071b92f1f6bc3c5c312a237ea91105b',1,'arm_math.h']]],
  ['arm_5fmath_5fsuccess',['ARM_MATH_SUCCESS',['../arm__math_8h.html#a5e459c6409dfcd2927bb8a57491d7cf6a9f8b2a10bd827fb4600e77d455902eb0',1,'arm_math.h']]],
  ['arm_5fmath_5ftest_5ffailure',['ARM_MATH_TEST_FAILURE',['../arm__math_8h.html#a5e459c6409dfcd2927bb8a57491d7cf6a09457f2be656b35015fd6d36202fa376',1,'arm_math.h']]]
];
