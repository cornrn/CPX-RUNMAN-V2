var searchData=
[
  ['snr_5fthreshold',['SNR_THRESHOLD',['../_a_r_m_2arm__convolution__example__f32_8c.html#af08ec3fef897d77c6817638bf0e0c5c6',1,'SNR_THRESHOLD():&#160;arm_convolution_example_f32.c'],['../_g_c_c_2arm__convolution__example__f32_8c.html#af08ec3fef897d77c6817638bf0e0c5c6',1,'SNR_THRESHOLD():&#160;arm_convolution_example_f32.c'],['../arm__linear__interp__example__f32_8c.html#af08ec3fef897d77c6817638bf0e0c5c6',1,'SNR_THRESHOLD():&#160;arm_linear_interp_example_f32.c'],['../arm__matrix__example__f32_8c.html#af08ec3fef897d77c6817638bf0e0c5c6',1,'SNR_THRESHOLD():&#160;arm_matrix_example_f32.c']]],
  ['snr_5fthreshold_5ff32',['SNR_THRESHOLD_F32',['../arm__fir__example__f32_8c.html#af7d1dd4deffa8e7ed6429e5dd0fe1812',1,'SNR_THRESHOLD_F32():&#160;arm_fir_example_f32.c'],['../arm__graphic__equalizer__example__q31_8c.html#af7d1dd4deffa8e7ed6429e5dd0fe1812',1,'SNR_THRESHOLD_F32():&#160;arm_graphic_equalizer_example_q31.c']]]
];
