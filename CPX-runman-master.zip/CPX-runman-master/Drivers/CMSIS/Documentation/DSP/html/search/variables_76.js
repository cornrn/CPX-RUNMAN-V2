var searchData=
[
  ['var',['var',['../_a_r_m_2arm__class__marks__example__f32_8c.html#a3bd39c4335d84be071cc1eaa9b0a8642',1,'var():&#160;arm_class_marks_example_f32.c'],['../_g_c_c_2arm__class__marks__example__f32_8c.html#a3bd39c4335d84be071cc1eaa9b0a8642',1,'var():&#160;arm_class_marks_example_f32.c']]]
];
