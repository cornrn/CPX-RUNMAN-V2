var searchData=
[
  ['use_5fstatic_5finit',['USE_STATIC_INIT',['../_a_r_m_2arm__class__marks__example__f32_8c.html#a821d6c5973940580f5a045e7cf64b7f2',1,'USE_STATIC_INIT():&#160;arm_class_marks_example_f32.c'],['../_g_c_c_2arm__class__marks__example__f32_8c.html#a821d6c5973940580f5a045e7cf64b7f2',1,'USE_STATIC_INIT():&#160;arm_class_marks_example_f32.c']]]
];
