var searchData=
[
  ['weights_5f128',['Weights_128',['../group___d_c_t4___i_d_c_t4.html#gad00f29d896d64d6da7afbbb9d3e182a4',1,'arm_dct4_init_f32.c']]],
  ['weights_5f2048',['Weights_2048',['../group___d_c_t4___i_d_c_t4.html#gac3a2a00b3106dfcb5e0a582f50c65692',1,'arm_dct4_init_f32.c']]],
  ['weights_5f512',['Weights_512',['../group___d_c_t4___i_d_c_t4.html#gaeb67b0be5b3c2139d660e02cedeed908',1,'arm_dct4_init_f32.c']]],
  ['weights_5f8192',['Weights_8192',['../group___d_c_t4___i_d_c_t4.html#ga45a8ec91e5da91790566105bc7e6f0c2',1,'arm_dct4_init_f32.c']]],
  ['weightsq15_5f128',['WeightsQ15_128',['../group___d_c_t4___i_d_c_t4.html#gaa4ff5e6f062efb1d1ec8c6c2207c3727',1,'arm_dct4_init_q15.c']]],
  ['weightsq15_5f2048',['WeightsQ15_2048',['../group___d_c_t4___i_d_c_t4.html#ga2235ec700d0d6925d9733f48541d46f5',1,'arm_dct4_init_q15.c']]],
  ['weightsq15_5f512',['WeightsQ15_512',['../group___d_c_t4___i_d_c_t4.html#gadc8ee250fc217d6cb5c84dd7c1eb6d31',1,'arm_dct4_init_q15.c']]],
  ['weightsq15_5f8192',['WeightsQ15_8192',['../group___d_c_t4___i_d_c_t4.html#ga4fdc60621eb306984a82ce8b2d645bb7',1,'arm_dct4_init_q15.c']]],
  ['weightsq31_5f128',['WeightsQ31_128',['../group___d_c_t4___i_d_c_t4.html#ga02d7024538a87214296b01d83ba36b02',1,'arm_dct4_init_q31.c']]],
  ['weightsq31_5f2048',['WeightsQ31_2048',['../group___d_c_t4___i_d_c_t4.html#ga725b65c25a02b3cad329e18bb832f65e',1,'arm_dct4_init_q31.c']]],
  ['weightsq31_5f512',['WeightsQ31_512',['../group___d_c_t4___i_d_c_t4.html#ga31a8217a96f7d3171921e98398f31596',1,'arm_dct4_init_q31.c']]],
  ['weightsq31_5f8192',['WeightsQ31_8192',['../group___d_c_t4___i_d_c_t4.html#ga16bf6bbe5c4c9b35f88253cf7bdcc435',1,'arm_dct4_init_q31.c']]],
  ['wire1',['wire1',['../arm__signal__converge__example__f32_8c.html#a16e759789fbc05f878863f009066c8ea',1,'wire1():&#160;arm_signal_converge_example_f32.c'],['../arm__variance__example__f32_8c.html#acc43b372d92d5027b9f9cac782c8b3c7',1,'wire1():&#160;arm_variance_example_f32.c']]],
  ['wire2',['wire2',['../arm__signal__converge__example__f32_8c.html#a4e370163c81ae2b72cc655a6b79e4c6a',1,'wire2():&#160;arm_signal_converge_example_f32.c'],['../arm__variance__example__f32_8c.html#a41a9afab5be5ccd2e6f618b83102f0d1',1,'wire2():&#160;arm_variance_example_f32.c']]],
  ['wire3',['wire3',['../arm__signal__converge__example__f32_8c.html#a7e2cceadf6ec7f0aa0f698a680fa3a4b',1,'wire3():&#160;arm_signal_converge_example_f32.c'],['../arm__variance__example__f32_8c.html#af61f43ad332a2322e43ced590b6d9768',1,'wire3():&#160;arm_variance_example_f32.c']]]
];
