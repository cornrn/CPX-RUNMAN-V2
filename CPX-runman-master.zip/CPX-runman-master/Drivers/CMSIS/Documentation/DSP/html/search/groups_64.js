var searchData=
[
  ['dct_20type_20iv_20functions',['DCT Type IV Functions',['../group___d_c_t4___i_d_c_t4.html',1,'']]],
  ['dot_20product_20example',['Dot Product Example',['../group___dotproduct_example.html',1,'']]]
];
