var searchData=
[
  ['gaindb',['gainDB',['../arm__graphic__equalizer__example__q31_8c.html#a963aee85bb41a50fc943ac9048d123ab',1,'arm_graphic_equalizer_example_q31.c']]]
];
