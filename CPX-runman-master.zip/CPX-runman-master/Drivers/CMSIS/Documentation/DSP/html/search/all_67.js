var searchData=
[
  ['arm_5fclass_5fmarks_5fexample_5ff32_2ec',['arm_class_marks_example_f32.c',['../_g_c_c_2arm__class__marks__example__f32_8c.html',1,'']]],
  ['arm_5fconvolution_5fexample_5ff32_2ec',['arm_convolution_example_f32.c',['../_g_c_c_2arm__convolution__example__f32_8c.html',1,'']]],
  ['arm_5fdotproduct_5fexample_5ff32_2ec',['arm_dotproduct_example_f32.c',['../_g_c_c_2arm__dotproduct__example__f32_8c.html',1,'']]],
  ['arm_5ffft_5fbin_5fdata_2ec',['arm_fft_bin_data.c',['../_g_c_c_2arm__fft__bin__data_8c.html',1,'']]],
  ['arm_5ffft_5fbin_5fexample_5ff32_2ec',['arm_fft_bin_example_f32.c',['../_g_c_c_2arm__fft__bin__example__f32_8c.html',1,'']]],
  ['gaindb',['gainDB',['../arm__graphic__equalizer__example__q31_8c.html#a963aee85bb41a50fc943ac9048d123ab',1,'arm_graphic_equalizer_example_q31.c']]],
  ['graphic_20audio_20equalizer_20example',['Graphic Audio Equalizer Example',['../group___g_e_q5_band.html',1,'']]],
  ['getinput',['getinput',['../arm__signal__converge__example__f32_8c.html#afd2975c4763ec935771e6f63bfe7758b',1,'arm_signal_converge_example_f32.c']]]
];
