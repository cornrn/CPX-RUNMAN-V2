var searchData=
[
  ['clip_5fq31_5fto_5fq15',['clip_q31_to_q15',['../arm__math_8h.html#a4af3ca330e14587289518e6565fd04bd',1,'arm_math.h']]],
  ['clip_5fq31_5fto_5fq7',['clip_q31_to_q7',['../arm__math_8h.html#aa9918ce19228b0d4f072fb84776eabc1',1,'arm_math.h']]],
  ['clip_5fq63_5fto_5fq15',['clip_q63_to_q15',['../arm__math_8h.html#aa6f1e5d0d276f42217e75f071ca84a2e',1,'arm_math.h']]],
  ['clip_5fq63_5fto_5fq31',['clip_q63_to_q31',['../arm__math_8h.html#ad7373e53d3c2e1adfeafc8c2e9720b5c',1,'arm_math.h']]]
];
