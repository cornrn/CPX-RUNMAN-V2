var group__cmplx__mag__squared =
[
    [ "arm_cmplx_mag_squared_f32", "group__cmplx__mag__squared.html#gaa7faccc0d96b061d8b7d0d7d82045074", null ],
    [ "arm_cmplx_mag_squared_q15", "group__cmplx__mag__squared.html#ga45537f576102d960d467eb722b8431f2", null ],
    [ "arm_cmplx_mag_squared_q31", "group__cmplx__mag__squared.html#ga384b0538101e8c03fa4fa14271e63b04", null ]
];