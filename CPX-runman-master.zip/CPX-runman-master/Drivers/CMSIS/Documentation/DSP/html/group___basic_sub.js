var group___basic_sub =
[
    [ "arm_sub_f32", "group___basic_sub.html#ga7f975a472de286331134227c08aad826", null ],
    [ "arm_sub_q15", "group___basic_sub.html#ga997a8ee93088d15bda23c325d455b588", null ],
    [ "arm_sub_q31", "group___basic_sub.html#ga28aa6908d092752144413e21933dc878", null ],
    [ "arm_sub_q7", "group___basic_sub.html#gab09941de7dfeb247e5c29b406a435fcc", null ]
];