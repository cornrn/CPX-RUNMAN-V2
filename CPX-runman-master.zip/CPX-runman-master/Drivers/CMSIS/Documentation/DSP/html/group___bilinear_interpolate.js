var group___bilinear_interpolate =
[
    [ "arm_bilinear_interp_f32", "group___bilinear_interpolate.html#gab49a4c0f64854903d996d01ba38f711a", null ],
    [ "arm_bilinear_interp_q15", "group___bilinear_interpolate.html#gaa8dffbc2a01bb7accf231384498ec85e", null ],
    [ "arm_bilinear_interp_q31", "group___bilinear_interpolate.html#ga202a033c8a2ad3678b136f93153b6d13", null ],
    [ "arm_bilinear_interp_q7", "group___bilinear_interpolate.html#gade8db9706a3ae9ad03b2750a239d2ee6", null ]
];