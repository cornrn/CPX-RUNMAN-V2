var structarm__iir__lattice__instance__q31 =
[
    [ "numStages", "structarm__iir__lattice__instance__q31.html#a9df4570ed28c50fd9193ab654ff236ad", null ],
    [ "pkCoeffs", "structarm__iir__lattice__instance__q31.html#a1d30aa16aac7722936ea9dee59211863", null ],
    [ "pState", "structarm__iir__lattice__instance__q31.html#a941282745effd26a889fbfadf4b95e6a", null ],
    [ "pvCoeffs", "structarm__iir__lattice__instance__q31.html#a04507e2b982b1dfa97b7b55752dea6b9", null ]
];