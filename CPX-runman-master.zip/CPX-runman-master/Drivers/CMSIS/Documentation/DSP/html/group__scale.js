var group__scale =
[
    [ "arm_scale_f32", "group__scale.html#ga3487af88b112f682ee90589cd419e123", null ],
    [ "arm_scale_q15", "group__scale.html#gafaac0e1927daffeb68a42719b53ea780", null ],
    [ "arm_scale_q31", "group__scale.html#ga83e36cd82bf51ce35406a199e477d47c", null ],
    [ "arm_scale_q7", "group__scale.html#gabc9fd3d37904c58df56492b351d21fb0", null ]
];