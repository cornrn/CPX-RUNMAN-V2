var group__negate =
[
    [ "arm_negate_f32", "group__negate.html#ga2e169c4de6cc6e3ba4be9473531e6657", null ],
    [ "arm_negate_q15", "group__negate.html#ga0239a833d72cf00290b9723c394e5042", null ],
    [ "arm_negate_q31", "group__negate.html#ga2784c6887686a73dc7c364e2e41c776c", null ],
    [ "arm_negate_q7", "group__negate.html#gaae78fc079a43bdaa3055f9b32e2a1f4c", null ]
];