var group__group_controller =
[
    [ "Sine Cosine", "group___sin_cos.html", "group___sin_cos" ],
    [ "PID Motor Control", "group___p_i_d.html", "group___p_i_d" ],
    [ "Vector Clarke Transform", "group__clarke.html", "group__clarke" ],
    [ "Vector Inverse Clarke Transform", "group__inv__clarke.html", "group__inv__clarke" ],
    [ "Vector Park Transform", "group__park.html", "group__park" ],
    [ "Vector Inverse Park transform", "group__inv__park.html", "group__inv__park" ]
];