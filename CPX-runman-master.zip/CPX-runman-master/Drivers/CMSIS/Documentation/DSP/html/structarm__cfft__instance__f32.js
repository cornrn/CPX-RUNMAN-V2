var structarm__cfft__instance__f32 =
[
    [ "bitRevLength", "structarm__cfft__instance__f32.html#a3ba329ed153d182746376208e773d648", null ],
    [ "fftLen", "structarm__cfft__instance__f32.html#acd8f9e9540e3dd348212726e5d6aaa95", null ],
    [ "pBitRevTable", "structarm__cfft__instance__f32.html#a21ceaf59a1bb8440af57c28d2dd9bbab", null ],
    [ "pTwiddle", "structarm__cfft__instance__f32.html#a59cc6f753f1498716e1444ac054c06de", null ]
];