var group___s_q_r_t =
[
    [ "arm_sqrt_f32", "group___s_q_r_t.html#ga56a40d1cf842b0b45267df6761975da0", null ],
    [ "arm_sqrt_q15", "group___s_q_r_t.html#ga5abe5ca724f3e15849662b03752c1238", null ],
    [ "arm_sqrt_q31", "group___s_q_r_t.html#ga119e25831e141d734d7ef10636670058", null ]
];