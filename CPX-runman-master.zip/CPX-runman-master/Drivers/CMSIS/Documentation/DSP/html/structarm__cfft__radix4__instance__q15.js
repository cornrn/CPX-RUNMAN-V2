var structarm__cfft__radix4__instance__q15 =
[
    [ "bitReverseFlag", "structarm__cfft__radix4__instance__q15.html#a101e3f7b0bd6b5b14cd5214f23df4133", null ],
    [ "bitRevFactor", "structarm__cfft__radix4__instance__q15.html#a6b010e5f02d1130c621e3d2e26b95df1", null ],
    [ "fftLen", "structarm__cfft__radix4__instance__q15.html#a5fc543e7d84ca8cb7cf6648970f21ca6", null ],
    [ "ifftFlag", "structarm__cfft__radix4__instance__q15.html#a2ecff6ea735cb4d22e922d0fd5736655", null ],
    [ "pBitRevTable", "structarm__cfft__radix4__instance__q15.html#a4acf704ae0cf30b53bf0fbfae8e34a59", null ],
    [ "pTwiddle", "structarm__cfft__radix4__instance__q15.html#a29dd693537e45421a36891f8439e1fba", null ],
    [ "twidCoefModifier", "structarm__cfft__radix4__instance__q15.html#af32fdc78bcc27ca385f9b76a0a1f71c3", null ]
];