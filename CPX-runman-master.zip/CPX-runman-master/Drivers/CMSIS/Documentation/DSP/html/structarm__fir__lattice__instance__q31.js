var structarm__fir__lattice__instance__q31 =
[
    [ "numStages", "structarm__fir__lattice__instance__q31.html#a9f3773bbb76bc5a8a5ee9d37786bf478", null ],
    [ "pCoeffs", "structarm__fir__lattice__instance__q31.html#a66c3364bf5863cd45e05f1652c3dc522", null ],
    [ "pState", "structarm__fir__lattice__instance__q31.html#a08fe9494ab7cd336b791e9657adadcf6", null ]
];