var group___biquad_cascade_d_f2_t =
[
    [ "arm_biquad_cascade_df2T_f32", "group___biquad_cascade_d_f2_t.html#ga114f373fbc16a314e9f293c7c7649c7f", null ],
    [ "arm_biquad_cascade_df2T_f64", "group___biquad_cascade_d_f2_t.html#gaa8735dda5f3f36d0936283794c2aa771", null ],
    [ "arm_biquad_cascade_df2T_init_f32", "group___biquad_cascade_d_f2_t.html#ga70eaddf317a4a8bde6bd6a97df67fedd", null ],
    [ "arm_biquad_cascade_df2T_init_f64", "group___biquad_cascade_d_f2_t.html#ga12dc5d8e8892806ad70e79ca2ff9f86e", null ],
    [ "arm_biquad_cascade_stereo_df2T_f32", "group___biquad_cascade_d_f2_t.html#gac75de449c3e4f733477d81bd0ada5eec", null ],
    [ "arm_biquad_cascade_stereo_df2T_init_f32", "group___biquad_cascade_d_f2_t.html#ga405197c89fe4d34003efd23786296425", null ]
];