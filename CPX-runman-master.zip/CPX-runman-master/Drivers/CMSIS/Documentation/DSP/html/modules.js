var modules =
[
    [ "Basic Math Functions", "group__group_math.html", "group__group_math" ],
    [ "Fast Math Functions", "group__group_fast_math.html", "group__group_fast_math" ],
    [ "Complex Math Functions", "group__group_cmplx_math.html", "group__group_cmplx_math" ],
    [ "Filtering Functions", "group__group_filters.html", "group__group_filters" ],
    [ "Matrix Functions", "group__group_matrix.html", "group__group_matrix" ],
    [ "Transform Functions", "group__group_transforms.html", "group__group_transforms" ],
    [ "Controller Functions", "group__group_controller.html", "group__group_controller" ],
    [ "Statistics Functions", "group__group_stats.html", "group__group_stats" ],
    [ "Support Functions", "group__group_support.html", "group__group_support" ],
    [ "Interpolation Functions", "group__group_interpolation.html", "group__group_interpolation" ],
    [ "Examples", "group__group_examples.html", "group__group_examples" ]
];