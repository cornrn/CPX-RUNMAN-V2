var group__group_examples =
[
    [ "Class Marks Example", "group___class_marks.html", null ],
    [ "Convolution Example", "group___convolution_example.html", null ],
    [ "Dot Product Example", "group___dotproduct_example.html", null ],
    [ "Frequency Bin Example", "group___frequency_bin.html", null ],
    [ "FIR Lowpass Filter Example", "group___f_i_r_l_p_f.html", null ],
    [ "Graphic Audio Equalizer Example", "group___g_e_q5_band.html", null ],
    [ "Linear Interpolate Example", "group___linear_interp_example.html", null ],
    [ "Matrix Example", "group___matrix_example.html", null ],
    [ "Signal Convergence Example", "group___signal_convergence.html", null ],
    [ "SineCosine Example", "group___sin_cos_example.html", null ],
    [ "Variance Example", "group___variance_example.html", null ]
];