var group___basic_abs =
[
    [ "arm_abs_f32", "group___basic_abs.html#ga421b6275f9d35f50286c0ff3beceff02", null ],
    [ "arm_abs_q15", "group___basic_abs.html#ga39f92964c9b649ba252e26ebe7b95594", null ],
    [ "arm_abs_q31", "group___basic_abs.html#ga59eafcdcdb52da60d37f20aec6ff4577", null ],
    [ "arm_abs_q7", "group___basic_abs.html#gadc30985e33fbf96802a5a7954dece3b1", null ]
];