var group___biquad_cascade_d_f1__32x64 =
[
    [ "arm_biquad_cas_df1_32x64_init_q31", "group___biquad_cascade_d_f1__32x64.html#ga44900cecb8083afcaabf905ffcd656bb", null ],
    [ "arm_biquad_cas_df1_32x64_q31", "group___biquad_cascade_d_f1__32x64.html#ga953a83e69685de6575cff37feb358a93", null ]
];