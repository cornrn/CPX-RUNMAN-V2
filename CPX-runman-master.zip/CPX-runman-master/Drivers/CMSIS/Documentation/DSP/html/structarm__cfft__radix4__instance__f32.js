var structarm__cfft__radix4__instance__f32 =
[
    [ "bitReverseFlag", "structarm__cfft__radix4__instance__f32.html#ac10927a1620195a88649ce63dab66120", null ],
    [ "bitRevFactor", "structarm__cfft__radix4__instance__f32.html#acc8cb18a8b901b8321ab9d86491e41a3", null ],
    [ "fftLen", "structarm__cfft__radix4__instance__f32.html#a7e6a6d290ce158ce9a15a45e364b021a", null ],
    [ "ifftFlag", "structarm__cfft__radix4__instance__f32.html#a25d1da64dd6487c291f04d226f9acc66", null ],
    [ "onebyfftLen", "structarm__cfft__radix4__instance__f32.html#ab9eed39e40b8d7c16381fbccf84467cd", null ],
    [ "pBitRevTable", "structarm__cfft__radix4__instance__f32.html#a8da0d2ca69749fde8cbb95caeac6fe6a", null ],
    [ "pTwiddle", "structarm__cfft__radix4__instance__f32.html#a14860c7544911702ca1fa0bf78204ef3", null ],
    [ "twidCoefModifier", "structarm__cfft__radix4__instance__f32.html#abe31ea2157dfa233e389cdfd3b9993ee", null ]
];