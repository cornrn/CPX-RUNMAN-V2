var structarm__fir__instance__q31 =
[
    [ "numTaps", "structarm__fir__instance__q31.html#a918fadd775b7a0482b21bf34dae2f094", null ],
    [ "pCoeffs", "structarm__fir__instance__q31.html#afaae4c884bdf11a4ec2f3b9bb2bb51d0", null ],
    [ "pState", "structarm__fir__instance__q31.html#a409f39c93b744784648bdc365541444d", null ]
];