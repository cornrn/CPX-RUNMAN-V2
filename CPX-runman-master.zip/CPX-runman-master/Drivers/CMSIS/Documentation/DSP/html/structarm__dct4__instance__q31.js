var structarm__dct4__instance__q31 =
[
    [ "N", "structarm__dct4__instance__q31.html#a46a9f136457350676e2bfd3768ff9d6d", null ],
    [ "Nby2", "structarm__dct4__instance__q31.html#a32d3268ba4629908dba056599f0a904d", null ],
    [ "normalize", "structarm__dct4__instance__q31.html#ac80ff7b28fca36aeef74dea12e8312dd", null ],
    [ "pCfft", "structarm__dct4__instance__q31.html#ac96579cfb28d08bb11dd2fe4c6303833", null ],
    [ "pCosFactor", "structarm__dct4__instance__q31.html#af97204d1838925621fc82021a0c2d6c1", null ],
    [ "pRfft", "structarm__dct4__instance__q31.html#af1487dab5e7963b85dc0fdc6bf492542", null ],
    [ "pTwiddle", "structarm__dct4__instance__q31.html#a7db236e22673146bb1d2c962f0713f08", null ]
];