var struct_sys_tick___type =
[
    [ "CALIB", "struct_sys_tick___type.html#afcadb0c6d35b21cdc0018658a13942de", null ],
    [ "CTRL", "struct_sys_tick___type.html#a875e7afa5c4fd43997fb544a4ac6e37e", null ],
    [ "LOAD", "struct_sys_tick___type.html#a4780a489256bb9f54d0ba8ed4de191cd", null ],
    [ "VAL", "struct_sys_tick___type.html#a9b5420d17e8e43104ddd4ae5a610af93", null ]
];